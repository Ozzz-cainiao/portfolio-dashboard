(() => {
  const REQUEST = 'portfolio-yzyx-auto-request-v1',
    RESPONSE = 'portfolio-yzyx-auto-state-v1';
  function post(result) {
    window.postMessage({ channel: RESPONSE, ...result }, location.origin);
  }
  window.addEventListener('message', async (event) => {
    if (
      event.source !== window ||
      event.origin !== location.origin ||
      event.data?.channel !== REQUEST
    )
      return;
    const { type, ids } = event.data;
    if (!['STATUS', 'ENABLE', 'DISABLE', 'REFRESH'].includes(type)) return;
    try {
      post(await chrome.runtime.sendMessage({ type, ids }));
    } catch (error) {
      post({ ok: false, error: error.message });
    }
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'AUTO_SYNC_STATE')
      post({ ok: true, state: message.state });
  });
  chrome.runtime
    .sendMessage({ type: 'STATUS' })
    .then(post)
    .catch(() => {});
})();
