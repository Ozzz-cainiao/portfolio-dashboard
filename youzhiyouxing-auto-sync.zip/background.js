import {
  ALARM,
  DASHBOARD,
  SOURCE,
  isDashboard,
  sourceId,
  validateIds,
  allowedCapture,
} from './core.js';

let job = null;
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function load() {
  return await chrome.storage.local.get(['config', 'captures', 'status']);
}
async function notify() {
  const state = await load();
  const tabs = await chrome.tabs.query({ url: DASHBOARD + '*' });
  await Promise.allSettled(
    tabs.map((tab) =>
      chrome.tabs.sendMessage(tab.id, { type: 'AUTO_SYNC_STATE', state }),
    ),
  );
}
async function accept(capture, id) {
  const state = await load();
  if (
    !state.config?.enabled ||
    !state.config.ids.includes(id) ||
    !allowedCapture(capture, id)
  )
    throw new Error('账户未启用或来源不匹配');
  const captures = {
    ...state.captures,
    [id]: { capture, capturedAt: new Date().toISOString() },
  };
  await chrome.storage.local.set({ captures });
  await notify();
}
async function run() {
  if (job) return job;
  job = (async () => {
    const { config } = await load();
    if (!config?.enabled) return;
    const errors = {};
    await chrome.storage.local.set({
      status: { running: true, checkedAt: new Date().toISOString(), errors },
    });
    await notify();
    for (const id of config.ids) {
      const current = await load();
      if (!current.config?.enabled || !current.config.ids.includes(id)) break;
      let tab;
      try {
        // Owned temporary tab: never reload or close a tab the user is editing.
        tab = await chrome.tabs.create({ url: SOURCE + id, active: false });
        let response;
        for (let attempt = 0; attempt < 20; attempt++) {
          await wait(1500);
          try {
            response = await chrome.tabs.sendMessage(tab.id, {
              type: 'READ_ACCOUNT',
            });
          } catch {
            continue;
          }
          if (response?.ok) break;
        }
        if (!response?.ok)
          throw new Error(
            '登录失效或账户未加载；请在 Chrome 登录有知有行后重试',
          );
        await accept(response.capture, id);
      } catch (error) {
        errors[id] = error.message;
      } finally {
        if (tab?.id) await chrome.tabs.remove(tab.id).catch(() => {});
      }
    }
    await chrome.storage.local.set({
      status: { running: false, checkedAt: new Date().toISOString(), errors },
    });
    await notify();
  })().finally(() => {
    job = null;
  });
  return job;
}
async function ensureAlarm() {
  const { config } = await load();
  if (config?.enabled) {
    if (!(await chrome.alarms.get(ALARM)))
      await chrome.alarms.create(ALARM, { periodInMinutes: 5 });
  } else await chrome.alarms.clear(ALARM);
}
chrome.runtime.onInstalled.addListener(() => {
  void ensureAlarm();
});
chrome.runtime.onStartup.addListener(() => {
  void ensureAlarm().then(() => run());
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) void run();
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  (async () => {
    if (message?.type === 'SOURCE_CAPTURE') {
      const id = sourceId(sender.url);
      if (!id || sender.frameId !== 0) throw new Error('来源页面不匹配');
      await accept(message.capture, id);
      return { ok: true };
    }
    if (!isDashboard(sender.url) || sender.frameId !== 0)
      throw new Error('仅允许个人 dashboard 控制同步');
    if (message.type === 'STATUS') return { ok: true, state: await load() };
    if (message.type === 'ENABLE') {
      const ids = validateIds(message.ids);
      const previous = await load();
      // Do not deliver captures belonging to an account no longer configured.
      const captures = Object.fromEntries(
        Object.entries(previous.captures || {}).filter(([id]) =>
          ids.includes(id),
        ),
      );
      await chrome.storage.local.set({
        config: { enabled: true, ids },
        captures,
      });
      await ensureAlarm();
      void run();
      return { ok: true, state: await load() };
    }
    if (message.type === 'DISABLE') {
      await chrome.storage.local.set({
        config: { enabled: false, ids: [] },
        captures: {},
        status: { running: false, errors: {} },
      });
      await ensureAlarm();
      await notify();
      return { ok: true, state: await load() };
    }
    if (message.type === 'REFRESH') {
      void run();
      return { ok: true, state: await load() };
    }
    throw new Error('不支持的操作');
  })().then(reply, (error) => reply({ ok: false, error: error.message }));
  return true;
});
void ensureAlarm();
