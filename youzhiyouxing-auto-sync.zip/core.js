export const DASHBOARD = 'https://ozzz-cainiao.github.io/portfolio-dashboard/';
export const SOURCE = 'https://yx.youzhiyouxing.cn/abooks/accounts/';
export const ALARM = 'yzyx-refresh';
export function isDashboard(url) {
  try {
    const u = new URL(url);
    return (
      u.origin === 'https://ozzz-cainiao.github.io' &&
      u.pathname.startsWith('/portfolio-dashboard/')
    );
  } catch {
    return false;
  }
}
export function sourceId(url) {
  try {
    const u = new URL(url);
    return u.origin === 'https://yx.youzhiyouxing.cn'
      ? u.pathname.match(/^\/abooks\/accounts\/(\d+)$/)?.[1] || null
      : null;
  } catch {
    return null;
  }
}
export function validateIds(ids) {
  if (
    !Array.isArray(ids) ||
    !ids.length ||
    ids.length > 20 ||
    ids.some((id) => typeof id !== 'string' || !/^\d+$/.test(id))
  )
    throw new Error('请选择 1～20 个已绑定账户');
  return [...new Set(ids)];
}
export function allowedCapture(raw, id) {
  return (
    raw?.source === 'youzhiyouxing' &&
    sourceId(raw.sourceUrl) === id &&
    typeof raw.accountName === 'string' &&
    typeof raw.totalText === 'string' &&
    Array.isArray(raw.records) &&
    raw.records.length > 0 &&
    raw.records.length <= 10000 &&
    raw.records.every(
      (r) =>
        typeof r.sourceRecordId === 'string' &&
        /^\d+$/.test(r.sourceRecordId) &&
        Array.isArray(r.fields) &&
        r.fields.length === 3 &&
        r.fields.every((f) => typeof f === 'string' && f.length < 1000),
    )
  );
}
