(() => {
  let timer,
    last = '';
  function read() {
    return extractYzyxAccount(document, location.href);
  }
  async function publish() {
    try {
      const capture = read(),
        serialized = JSON.stringify(capture);
      if (serialized === last) return;
      const result = await chrome.runtime.sendMessage({
        type: 'SOURCE_CAPTURE',
        capture,
      });
      if (result?.ok) last = serialized;
    } catch {
      /* A loading or signed-out page never overwrites the last good capture. */
    }
  }
  const observer = new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(publish, 1000);
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
  });
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message?.type !== 'READ_ACCOUNT') return;
    try {
      reply({ ok: true, capture: read() });
    } catch (error) {
      reply({ ok: false, error: error.message });
    }
  });
  setTimeout(publish, 1500);
})();
