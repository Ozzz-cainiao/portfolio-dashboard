// Runs in the extension's isolated content-script world. Reads rendered DOM only.
function extractYzyxAccount(doc, href) {
  const url = new URL(href);
  const match =
    url.origin === 'https://yx.youzhiyouxing.cn' &&
    url.pathname.match(/^\/abooks\/accounts\/(\d+)$/);
  if (!match) throw new Error('需要登录有知有行并打开独立记账资产');
  const root = doc.getElementById(`account-book-account-detail-${match[1]}`);
  if (!root) throw new Error('未找到当前账户的详情区域');
  const title = root.querySelector('h1');
  const total = Array.from(root.querySelectorAll('p')).find(
    (el) => el.textContent.trim() === '总资产',
  );
  const buttons = Array.from(
    root.querySelectorAll('button[aria-label="编辑记录"][phx-value-rid]'),
  );
  if (!title || !total?.nextElementSibling || !buttons.length)
    throw new Error('账户尚未加载、登录已过期，或页面结构已变化');
  const totalText = total.nextElementSibling.textContent.trim();
  if (!totalText.includes('¥') && !totalText.includes('￥'))
    throw new Error('当前版本仅支持已核实的人民币账户');
  const records = buttons.map((el) => ({
    sourceRecordId: el.getAttribute('phx-value-rid'),
    fields: Array.from(
      el.parentElement.parentElement.querySelectorAll('p'),
    ).map((p) => p.textContent.trim()),
  }));
  if (
    records.some(
      (r) => !/^\d+$/.test(r.sourceRecordId) || r.fields.length !== 3,
    )
  )
    throw new Error('记录结构发生变化，已停止抓取');
  if (new Set(records.map((r) => r.sourceRecordId)).size !== records.length)
    throw new Error('发现重复来源记录 ID');
  return {
    source: 'youzhiyouxing',
    sourceUrl: url.origin + url.pathname,
    accountName: title.textContent.trim(),
    totalText,
    records,
  };
}
